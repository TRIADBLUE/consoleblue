// ============================================================
// PATCH: server/routes/projects.ts
// Add auto-doc generation hook to POST /api/projects
// ============================================================
//
// In the existing createProjectRoutes function, add the
// DocGeneratorService import and trigger it after project creation.
//
// STEP 1: Add import at top of file
// ------------------------------------------------------------

import { DocGeneratorService } from "../services/doc-generator.service";

// STEP 2: Update the function signature to accept docGenerator
// ------------------------------------------------------------
// Change:
//   export function createProjectRoutes(db, auditService)
// To:
//   export function createProjectRoutes(db, auditService)
//
// Then create the service inside:

// Inside createProjectRoutes, after `const router = Router();` add:
const docGenerator = new DocGeneratorService(db, auditService);

// STEP 3: In the POST "/" handler, after the audit log, add:
// ------------------------------------------------------------
// This goes right after:
//   await auditService.log({ action: "create", ... });
//
// Add this block:

// ── Auto-generate onboarding docs ──
try {
  const genResult = await docGenerator.generateForNewProject(project.id);
  console.log(
    `[projects] Auto-generated ${genResult.docsCreated} docs for ${project.slug}` +
    (genResult.autoPushed ? ` (pushed to GitHub: ${genResult.commitSha?.slice(0, 7)})` : "")
  );
} catch (docErr) {
  // Don't fail the project creation if doc generation fails
  console.error(`[projects] Doc auto-generation failed for ${project.slug}:`, docErr);
}

// The response remains the same:
// res.status(201).json({ project });
