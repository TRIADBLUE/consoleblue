# ConsoleBlue Markdown Planner — Integration Guide

## Overview

This feature adds **auto-generated onboarding documentation** to ConsoleBlue. When a new project is created (or manually triggered), the system:

1. **Auto-generates 4 onboarding docs** (policy, procedures, handbook) populated with project data
2. **Fires a popup notification** to all team members — they MUST acknowledge before doing work
3. **Auto-pushes CLAUDE.md** to the project's GitHub repo (if configured)
4. **Provides regeneration** — docs can be refreshed when project data changes

These documents are NOT prompts. They are **policy, procedure, and handbook** content that defines rules, restrictions, and standards.

---

## New Files to Add

### Server

| File | Location | Purpose |
|------|----------|---------|
| `doc-generator.service.ts` | `server/services/` | Core engine — templates, auto-generation, assembly, notification, auto-push |
| `doc-generator.ts` | `server/routes/` | API endpoints for generate, regenerate, templates |

### Client

| File | Location | Purpose |
|------|----------|---------|
| `NewProjectDocsAlert.tsx` | `client/src/components/docs/` | Popup modal that appears for unread "new_project_docs" notifications |
| `DocPlanner.tsx` | `client/src/components/docs/` | UI in the project Docs tab showing generation status and controls |
| `use-doc-generator.ts` | `client/src/hooks/` | React hooks for the doc generator API |

---

## Existing Files to Modify

### 1. `server/routes.ts` — Register new routes

Add import and route registration:

```typescript
// Add to imports:
import { createDocGeneratorRoutes } from "./routes/doc-generator";

// Add to route registrations (after doc-push routes):

// Doc generator templates (global)
app.use("/api/doc-generator", createDocGeneratorRoutes(db, auditService));

// Doc auto-generation (per-project)
app.use(
  "/api/projects/:idOrSlug/generate-docs",
  createDocGeneratorRoutes(db, auditService),
);
```

### 2. `server/routes/projects.ts` — Auto-generate on project creation

In the `POST "/"` handler, after the audit log call, add:

```typescript
// Add import at top:
import { DocGeneratorService } from "../services/doc-generator.service";

// Inside createProjectRoutes, after const router = Router():
const docGenerator = new DocGeneratorService(db, auditService);

// In POST "/" handler, after auditService.log(...):
try {
  const genResult = await docGenerator.generateForNewProject(project.id);
  console.log(
    `[projects] Auto-generated ${genResult.docsCreated} docs for ${project.slug}` +
    (genResult.autoPushed ? ` (pushed: ${genResult.commitSha?.slice(0, 7)})` : "")
  );
} catch (docErr) {
  console.error(`[projects] Doc auto-gen failed for ${project.slug}:`, docErr);
}
```

### 3. `client/src/App.tsx` — Add popup notification component

```typescript
// Add import:
import { NewProjectDocsAlert } from "@/components/docs/NewProjectDocsAlert";

// Inside AuthGuard's success return (after {children}):
// Change:
//   return <>{children}</>;
// To:
//   return (
//     <>
//       {children}
//       <NewProjectDocsAlert />
//     </>
//   );
```

### 4. `client/src/pages/ProjectDetailPage.tsx` — Add DocPlanner to Docs tab

```typescript
// Add import:
import { DocPlanner } from "@/components/docs/DocPlanner";

// In the TabsContent value="docs" section, add DocPlanner BEFORE ProjectDocList:
<TabsContent value="docs">
  <div className="space-y-6">
    <DocPlanner
      projectSlug={project.slug}
      projectName={project.displayName}
      githubRepo={project.githubRepo}
      hasExistingDocs={(/* check if project has auto-generated docs */)}
    />
    <ProjectDocList projectSlug={project.slug} />
    <DocAssemblyPreview ... />
    <DocPushHistory ... />
  </div>
</TabsContent>
```

---

## Auto-Generated Doc Templates

The system creates 4 documents for each new project:

### 1. Company Identity & Overview (handbook)
- Who TriadBlue is
- Project purpose and ecosystem context
- Core values (consistency, transparency, documentation-first, approval required)

### 2. Project Restrictions & Boundaries (policy)
- Non-negotiable rules (no deployments without approval, no schema changes without docs, etc.)
- Branding restrictions (colors, asset standards)
- Data & privacy rules
- Communication standards

### 3. Unique Features & Capabilities (handbook)
- Project identity table (slug, status, branch, tags)
- ConsoleBlue integration points
- Custom configuration from project settings

### 4. General Direction & Development Standards (procedure)
- Work process (read docs → check tasks → work in phases → test → report)
- Tech stack standards
- Code standards
- Status-specific guidance (active, development, planned, maintenance, archived)

---

## Notification Flow

```
New Project Created
  ↓
DocGeneratorService.generateForNewProject()
  ↓
├── Create 4 project docs in database
├── Send "new_project_docs" notification to ALL admin users
├── If GitHub repo configured:
│   ├── Assemble full CLAUDE.md (shared docs + project docs)
│   ├── Push to GitHub repository
│   ├── Log push in doc_push_log
│   └── Send "doc_auto_pushed" follow-up notification
└── Log to audit trail
  ↓
Client: NewProjectDocsAlert detects unread notification
  ↓
Popup modal appears (cannot be dismissed without acknowledgment)
  ↓
User clicks "View Docs Now" or "I've Reviewed the Docs"
  ↓
Notification marked as read, modal closes
```

---

## API Endpoints

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/api/doc-generator/templates` | List available auto-generation templates |
| POST | `/api/projects/:slug/generate-docs` | Generate onboarding docs + notify + auto-push |
| POST | `/api/projects/:slug/generate-docs/regenerate` | Update existing auto-generated docs |

---

## Notification Types Added

| Type | Title | Trigger |
|------|-------|---------|
| `new_project_docs` | 📋 New Project Onboarded: {name} | Project created, docs generated |
| `doc_auto_pushed` | ✅ CLAUDE.md auto-pushed to {repo} | CLAUDE.md successfully pushed to GitHub |

The `new_project_docs` type triggers the popup modal (NewProjectDocsAlert).
The `doc_auto_pushed` type shows in the regular notification bell.

---

## Testing Checklist

- [ ] Create a new project → docs auto-generate
- [ ] Notification popup appears immediately
- [ ] Popup cannot be dismissed without clicking a button
- [ ] "View Docs Now" navigates to project docs tab
- [ ] "I've Reviewed the Docs" marks notification as read
- [ ] If GitHub repo is configured, CLAUDE.md is auto-pushed
- [ ] DocPushHistory shows the auto-push entry
- [ ] DocPlanner shows "Docs Generated" badge after generation
- [ ] Regenerate button updates docs with current project data
- [ ] Notification bell shows unread count for doc notifications
- [ ] Existing projects can manually trigger generation from Docs tab
